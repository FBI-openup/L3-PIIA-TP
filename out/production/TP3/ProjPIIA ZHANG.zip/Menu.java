package Proj;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Menu extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Texte diff Editor ");

        MenuBar menuBar = new MenuBar();

        // Files Menu
        javafx.scene.control.Menu fileMenu = new javafx.scene.control.Menu("Files");
        fileMenu.getItems().addAll(new MenuItem("Open file 1"), new MenuItem("Compare to file 2"));
        // load Icon
        Image image = new Image("file:/C:/PIIA_TP/Tp3_PIIA/src/Proj/images/filesMenuIcon.png");// the path to the image
        System.out.println("Finish loading image");
        ImageView imageView = new ImageView(image);
        imageView.setFitHeight(20); // set the size of the image
        imageView.setFitWidth(20);
        fileMenu.setGraphic(imageView);

        // undo and redo Menus
        javafx.scene.control.Menu undoMenu = new javafx.scene.control.Menu("Undo");
        javafx.scene.control.Menu redoMenu = new javafx.scene.control.Menu("Redo");

        // Comments Menu
        javafx.scene.control.Menu commentMenu = new javafx.scene.control.Menu("Comments");
        commentMenu.getItems().addAll(new MenuItem("Add comment"), new MenuItem("Delete comment"));

        // Format Menu
        javafx.scene.control.Menu formatMenu = new javafx.scene.control.Menu("Modifications");
        formatMenu.getItems().addAll(new MenuItem("Accept"), new MenuItem("Refuse"), new MenuItem("Previous"), new MenuItem("Next"));

        menuBar.getMenus().addAll(fileMenu, undoMenu,redoMenu, commentMenu, formatMenu);

        VBox vBox = new VBox(menuBar);
        Scene scene = new Scene(vBox, 640, 480);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
